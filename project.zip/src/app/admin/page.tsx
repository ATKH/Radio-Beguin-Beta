export default function AdminPage() {
  return (
    <div>
      <h1>Page Admin</h1>
      <p>Bienvenue dans l’espace d’administration</p>
    </div>
  );
}